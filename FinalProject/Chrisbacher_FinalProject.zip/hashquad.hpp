//Name: Case Chrisbacher
//Class: CSCI 2270
//Final Project

#ifndef HASHQUAD_HPP
#define HASHQUAD_HPP

#include <string>
#include <iostream>
using namespace std;


struct node
{
    int key;

};

class HashTable
{
    int tableSize;  // No. of buckets 

    // Pointer to an array containing buckets
    node* *table;
    int collision =0;
    node* createNode(int key);
public:
    HashTable(int bsize);  // Constructor

    // inserts a key into hash table
    bool insertItem(int key);

    // hash function to map values to key
    // unsigned int hashFunction(int key);

    int getNumOfCollision();
    int resetCollision();           //to 0

    node* searchItem(int key);
};

#endif
