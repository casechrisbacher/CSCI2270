//Name: Case Chrisbacher
//Class: CSCI 2270
//Final Project

#include <iostream>
#include <iomanip>
#include "dll.hpp"
using namespace std;



    dll :: dll(){
        head = NULL;
    }

    bool dll :: isEmpty(){
        if(head == NULL){           //no nodes if head is null
            return true;
        }
        else{
            return false;
        }
    }

    void dll :: insertNode(int inputkey){
        Node * headNode = head;
        Node * temp = new Node();
        temp->key = inputkey;

        if(head != NULL){                       //Inserts at the head and shifts the head to the next node
            headNode->previous = temp;         
            temp->next = headNode;
            head = temp;
        }
        else{
            head = temp;                    //If there is no head, the new node is it
        }
    }

    void dll :: searchNode(int inputkey){
        Node* temp = head;
        while(temp->key != inputkey){       //shuffles though the list until its found then while loop is broken
            temp = temp->next;
        }
    }




