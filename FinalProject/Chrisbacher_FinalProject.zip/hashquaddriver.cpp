//Name: Case Chrisbacher
//Class: CSCI 2270
//Final Project

#include "hashquad.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <time.h>
using namespace std;



int main(){
    int tableSize = 40009;
    HashTable c(tableSize);

    int testData[10000];            //from csv files
    int x = 0;
    int iteration = 0;
    int randomindex;
    int index = 0;
    int tempcounter;
    float count = 100;
    float colCount;
    int pseudoRandomNumbers[100];
    float averageInsert;
    float averageSearch;
    float insert[100];
    float search[100];
    float colInsert[100];
    ifstream text;
    ofstream writeto;
    string s;
    string dataSet = "dataSetA.csv";
    // string dataSet = "dataSetB.csv";

    text.open(dataSet);
    if(text.is_open()){                         //places integers from csv into the testData array
        while(getline(text, s, ',')){
            testData[x] = stoi(s);
            x++;
        }
    }
    text.close();


    while(iteration < 100){             //MEASURING LENGTH OF INSERT IN nanoseconds -- 100 iterations of 100 insert and search = 10,000 values
        tempcounter = 0;

        auto start = chrono::steady_clock::now();       //starts insert clock
        for(int j = 0; j < 100; j++){                      //runs through sets of 100 at a time
            c.insertItem(testData[index]);
            tempcounter++;
            index++;
        }
        auto end = chrono::steady_clock::now();             //ends insert clock

        averageInsert = chrono::duration_cast<chrono::nanoseconds>(end-start).count()/ count;       //average insert for 100 entries
        colCount = c.getNumOfCollision();                                                             //collisions for 100 inserts

        colInsert[iteration] = colCount;                //collisions into array
        insert[iteration] = averageInsert;              //inserts into array
        for(int i = 0; i < 100; i++){
            pseudoRandomNumbers[i] = rand() % (index +1);           //sets random number to 0-(index - 1)
            if(pseudoRandomNumbers[i] != 0){
                pseudoRandomNumbers[i] = pseudoRandomNumbers[i] - 1;
            }
        }
        
        auto s = chrono::steady_clock::now();               //search clock starts
        for(int i = 0; i < 100; i++){
            c.searchItem(testData[pseudoRandomNumbers[i]]);     //random number at random index to be searched
        }
        auto e = chrono::steady_clock::now();               //search clock ends after 100 searchees

        averageSearch = chrono::duration_cast<chrono::nanoseconds>(e-s).count()/ count;         //average of 100 searches
        search[iteration] = averageSearch;                                                      //put average in array at that iteration

        //cout<<"Avg Search time From 0-"<<index<<" === "<< search[iteration]<<" NANOSECONDS"<<endl;   //useful output statement

        iteration++;
        c.resetCollision();         //to 0

    }

    //*************COMMENTED OUT BECAUSE I DIDNT WANT ISSUES WITH WRITING TO FILES THAT DONT EXIST WHILE BEING GRADED***************

    // writeto.open("insert_search_hq_dataSetA.csv");      //exports data to CSV file
    // if(writeto.is_open()){
    //     for(int i = 0; i < 100; i++){
    //         writeto << insert[i] <<endl;            //1-100 lines insert
    //     }
    //     for(int i = 0; i < 100; i++){
    //         writeto << colInsert[i] <<endl;     //101-200 lines collisions
    //     }

    //     for(int i = 0; i < 100; i++){
    //         writeto << search[i] <<endl;            //201-300 lines search
    //     }

    // }

    // writeto.close();


}