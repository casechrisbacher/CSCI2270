//Name: Case Chrisbacher
//Class: CSCI 2270
//Final Project

#include "hashchain.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;



int main(){
    int tableSize = 40009;
    HashTable c(tableSize);

    int testData[10000];
    int x = 0;
    int iteration = 0;
    int randomindex;
    int index = 0;
    int tempcounter;
    float collisionCount;
    float count = 100;
    int pseudoRandomNumbers[100];
    float averageInsert;
    float averageSearch;
    float insert[100];
    float search[100];
    float colInsert[100];
    ifstream text;
    ofstream writeto;
    string s;
    string dataSet = "dataSetA.csv";                        //two data sets-- commented out one at a time
    // string dataSet = "dataSetB.csv";

    text.open(dataSet);
    if(text.is_open()){                             //stores all 10,000 integers in testData
        while(getline(text, s, ',')){
            testData[x] = stoi(s);
            x++;
        }
    }

       while(iteration < 100){             //MEASURING LENGTH OF INSERT IN NANOSECONDS-- 100 iterations of 100 insert & search == 10,000
        tempcounter = 0;

        auto start = chrono::steady_clock::now();       //starts clock for insert
        for(int j = 0; j < 100; j++){                      //runs through sets of 100 at a time
            c.insertItem(testData[index]);
            tempcounter++;
            index++;
        }
        auto end = chrono::steady_clock::now();         //stops clock for insert


        averageInsert = chrono::duration_cast<chrono::nanoseconds>(end-start).count()/ count;       //averages out insert
        collisionCount = c.getNumOfCollision();                                                     //counts total collisions for each 100 inserts 

        colInsert[iteration] = collisionCount;                                    //puts collisions into an array                    
        insert[iteration] = averageInsert;                                          //puts average of 100 inserts into array
        for(int i = 0; i < 100; i++){
            pseudoRandomNumbers[i] = rand() % (index +1);                       //random number generator
            if(pseudoRandomNumbers[i] != 0){
                pseudoRandomNumbers[i] = pseudoRandomNumbers[i] - 1;            //in place in case the random number = the index (SEG FAULT)
            }
        }
        
        auto s = chrono::steady_clock::now();                                   //start search item
        for(int i = 0; i < 100; i++){
            c.searchItem(testData[pseudoRandomNumbers[i]]);                         //searching for number at random index
        }
        auto e = chrono::steady_clock::now();                               //end search time after 100 searches

        averageSearch = chrono::duration_cast<chrono::nanoseconds>(e-s).count()/ count;     //average search
        search[iteration] = averageSearch;                                                  //place in array

        //cout<<"Avg Search time From 0-"<<index<<" === "<< search[iteration]<<" NANOSECONDS"<<endl;   //outputs average for each 100

        iteration++;
        c.resetCollision(); //resets collisions to 0
   
    }

    //*************COMMENTED OUT BECAUSE I DIDNT WANT ISSUES WITH WRITING TO FILES THAT DONT EXIST WHILE BEING GRADED***************
    

    // writeto.open("insert_search_hc_dataSetA.csv");      //writes to csv for later export
    // if(writeto.is_open()){
    //     for(int i = 0; i < 100; i++){
    //         writeto << insert[i] <<endl;    //1-100 insert avg
    //     }
    //     for(int i = 0; i < 100; i++){
    //         writeto << colInsert[i] <<endl;     //101-200 collisions avg
    //     }

    //     for(int i = 0; i < 100; i++){           //201-300 search avg
    //         writeto << search[i] <<endl;
    //     }

    // }

    // writeto.close();


}