//Name: Case Chrisbacher
//Class: CSCI 2270
//Final Project

#include "hashlinear.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

HashTable :: HashTable(int bsize){          //constructor
    tableSize = bsize;
    table = new node*[tableSize];
    for(int i = 0; i < tableSize; i++){         //initializes hash to NULL
        table[i] = NULL;
    }
}

bool HashTable :: insertItem(int key){
    int index = key % tableSize;                //MOD by table size to find index to insert at
    node * temp = new node();
    temp->key = key;                            //creates new node
    if(table[index] == NULL){
        table[index] = temp;                    //if the slot is empty, insert it
    }
    else{
 
        while(table[index] != NULL){            //need to find slot to insert
            if(index + 1 == tableSize){         //cannot insert at this index, resets to 0
                index = 0;
            }
            else{
                index++;                    //linear, so it increases by one until it finds an open slot
                
            }
            collision++;                   //each of these are a col
        }
        table[index] = temp;                  //when found, sets slot as the node
        
    }
    return true;
}

node* HashTable :: searchItem(int key){
    int index = key % tableSize;
    node * temp = new node();
    temp = table[index];
    if(temp->key == key){           //found in first slot
        return temp;
    }
    else{
        while(temp->key != key){        //looks at the next slot, until found
            index++;                    //linear
            temp = table[index];
            
        }
        return temp;

    }
}

int HashTable :: getNumOfCollision()
{
    return collision;
}

int HashTable :: resetCollision(){          //0
    collision = 0;
    return collision;
}